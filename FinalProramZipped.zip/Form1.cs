﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class Form1 : Form
    {



     

        private Timer _Timer = new Timer();

            
            private void Form1_Load(object sender, EventArgs e)
            {

                _Timer.Interval = 1000;

                _Timer.Tick += new EventHandler(_Timer_Tick);

                _Timer.Start();

            }

            void _Timer_Tick(object sender, EventArgs e)
            {

                this.label1.Text = DateTime.Now.ToString();

            }


    

        public Form1()
        {
            InitializeComponent();
        }
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

       

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click_1(object sender, EventArgs e)
        {

        }
    }
}
